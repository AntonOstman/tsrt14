function ess

%ESS Spoken letter 's'
%
% The letter 's' (ess) is spoken and the signal represents the microphone signal
% There are periods of silence, one segment with the 'e' sound and
% one segment with the 's' sound.

% Copyright Fredrik Gustafsson, Sigmoid AB
% $ Revision: v2023.4 $

help ess
load ess
plot(y)
