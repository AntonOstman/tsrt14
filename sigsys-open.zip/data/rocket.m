function rocket

%ROCKET IMU data from a Maxus rocket launch with GPS reference


% Copyright Fredrik Gustafsson, Sigmoid AB
% $ Revision: v2023.4 $


help rocket
load rocket


figure(1)
yplot(y)
