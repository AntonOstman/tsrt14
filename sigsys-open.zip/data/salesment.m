function salesment

% Signal Processing Lab Signal Database:
%
%        SALESMENT
%

% Copyright Fredrik Gustafsson, Sigmoid AB
% $ Revision: v2023.4 $


help salesment
