function planepath

%PLANEPATH Aircraft position from radar

% Copyright Fredrik Gustafsson, Sigmoid AB
% $ Revision: v2023.4 $


help planepath
load planepath
xplot2(y)
