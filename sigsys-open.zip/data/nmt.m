nfunction nmt450

%NMT Sales figures for cellular phones in the standard NMT 450 and 900

% Copyright Fredrik Gustafsson, Sigmoid AB
% $ Revision: v2023.4 $


help nmt
load nmt
subplot(2,1,1)
plot(y1)
subplot(2,1,2)
plot(y2)
